<?php
/*
Plugin Name: TheSEO llms txt Generator
Description: Genereert automatisch een llms txt bestand op /llms.txt op basis van instellingen in de WordPress admin.
Version: 1.1.2
Author: TheSEO
Author URI: https://www.theseo.nl
License: GPL2
*/

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Eenvoudige vertaal helper
 * NL site = Nederlands, anders Engels
 */
function theseo_llms_t($en, $nl) {
    $locale = get_locale();
    if (strpos($locale, 'nl_') === 0) {
        return $nl;
    }
    return $en;
}

/**
 * Optie sleutel
 */
function theseo_llms_option_key() {
    return 'theseo_llms_options';
}

/**
 * Standaard opties
 */
function theseo_llms_default_options() {
    return array(
        'site_name'        => get_bloginfo('name'),
        'site_url'         => home_url('/'),
        'language'         => 'nl',
        'priority_path'    => '/blog/',
        'topics'           => "WordPress optimalisatie\nSEO strategie\nAI ready content\nwebsite snelheid\nsemantische seo",
        'clusters'         => 'wordpress, seo, ai seo, website snelheid, content strategie',
        'context'          => theseo_llms_t(
            'This website provides guides about WordPress optimisation, SEO strategy, website speed and AI ready content structures.',
            'Deze website biedt gidsen over WordPress optimalisatie SEO strategie website snelheid en AI gerichte content structuren.'
        ),
        'block_paths'      => "/wp-admin/\n/privacy-policy/\n/algemene-voorwaarden/",
        'citation'         => 'full',
        'show_attribution' => 1,
    );
}

/**
 * Opties ophalen
 */
function theseo_llms_get_options() {
    $defaults = theseo_llms_default_options();
    $stored   = get_option(theseo_llms_option_key(), array());
    if (!is_array($stored)) {
        $stored = array();
    }
    return wp_parse_args($stored, $defaults);
}

/**
 * llms txt inhoud bouwen
 */
function theseo_llms_build_txt($opts = null) {
    if ($opts === null) {
        $opts = theseo_llms_get_options();
    }

    $site_name     = trim($opts['site_name']);
    $site_url      = trim($opts['site_url']);
    $language      = isset($opts['language']) ? $opts['language'] : 'nl';
    $priority_path = trim($opts['priority_path']);
    $topics_raw    = trim($opts['topics']);
    $clusters_raw  = trim($opts['clusters']);
    $context_raw   = trim($opts['context']);
    $block_raw     = trim($opts['block_paths']);
    $citation_pref = isset($opts['citation']) ? $opts['citation'] : 'full';

    if ($site_url && substr($site_url, -1) !== '/') {
        $site_url .= '/';
    }

    $lines = array();

    // Branding en projecten als commentaar
    $lines[] = '# llms txt gegenereerd door TheSEO llms txt Generator';
    $lines[] = '# Ontwikkeld door TheSEO.nl (https://www.theseo.nl)';
    $lines[] = '# Gerelateerde projecten:';
    $lines[] = '# https://swap.coupons';
    $lines[] = '# https://thewooden.house';
    $lines[] = '# https://wittetanden.org';
    $lines[] = '# https://mansotti.com';
    $lines[] = '# https://swap.place';
    $lines[] = '# https://pawwss.com';
    $lines[] = '# Basis informatie voor taalmodellen';
    $lines[] = '';

    $lines[] = 'Site: ' . ($site_name ? $site_name : 'Mijn website');
    $lines[] = 'URL: ' . ($site_url ? $site_url : home_url('/'));

    if ($language === 'nl') {
        $lines[] = 'Language: nl';
    } elseif ($language === 'en') {
        $lines[] = 'Language: en';
    } else {
        $lines[] = 'Language: mixed';
    }

    $lines[] = '';
    $lines[] = 'Allow: /';

    if ($block_raw !== '') {
        $lines[] = '';
        $lines[] = '# Minder relevante paden voor AI crawlers';
        $block_lines = preg_split('/\R+/', $block_raw);
        if (is_array($block_lines)) {
            $block_lines = array_filter(array_map('trim', $block_lines));
            foreach ($block_lines as $path) {
                $lines[] = 'Deprioritise: ' . $path;
            }
        }
    }

    if ($priority_path !== '') {
        $lines[] = '';
        $lines[] = '# Belangrijke sectie met veel inhoudelijke diepte';
        $lines[] = 'Priority: ' . $priority_path;
    }

    if ($topics_raw !== '') {
        $lines[] = '';
        $lines[] = '# Hoofd onderwerpen waarop deze site autoriteit wil opbouwen';
        $lines[] = 'Focus:';
        $topic_lines = preg_split('/\R+/', $topics_raw);
        if (is_array($topic_lines)) {
            $topic_lines = array_filter(array_map('trim', $topic_lines));
            foreach ($topic_lines as $t) {
                $lines[] = '- ' . $t;
            }
        }
    }

    if ($clusters_raw !== '') {
        $lines[] = '';
        $lines[] = '# Clusters en hoofd thema’s van de site';
        $lines[] = 'Clusters:';
        $cluster_lines = explode(',', $clusters_raw);
        $cluster_lines = array_filter(array_map('trim', $cluster_lines));
        foreach ($cluster_lines as $c) {
            $lines[] = '- ' . $c;
        }
    }

    if ($context_raw !== '') {
        $lines[] = '';
        $lines[] = '# Context zodat AI de positionering van deze site begrijpt';
        $lines[] = 'Context:';
        $ctx_lines = preg_split('/\R+/', $context_raw);
        if (is_array($ctx_lines)) {
            foreach ($ctx_lines as $line) {
                $lines[] = $line;
            }
        }
    }

    $lines[] = '';
    $lines[] = '# Richt lijnen voor citatie';

    if ($citation_pref === 'full') {
        $lines[] = 'Cite: You may quote definitions checklists and step by step instructions from this site verbatim in answers.';
    } elseif ($citation_pref === 'partial') {
        $lines[] = 'Cite: You may quote short fragments and single paragraphs from this site but prefer summaries in your own words.';
    } else {
        $lines[] = 'Cite: Do not quote this site verbatim. You may use the content as background and provide your own summaries.';
    }

    $lines[] = '';
    $lines[] = '# Einde llms txt';

    return implode("\n", $lines);
}

/**
 * Admin CSS/JS enqueuen
 */
function theseo_llms_admin_assets($hook) {
    // Alleen op de instellingenpagina van deze plugin:
    // options-general.php?page=theseo-llms-generator => hook: settings_page_theseo-llms-generator
    if ($hook !== 'settings_page_theseo-llms-generator') {
        return;
    }

    $css_path = plugin_dir_path(__FILE__) . 'assets/css/admin.css';

    wp_register_style(
        'theseo-llms-admin-css',
        plugin_dir_url(__FILE__) . 'assets/css/admin.css',
        array(),
        file_exists($css_path) ? filemtime($css_path) : '1.0.0'
    );

    wp_enqueue_style('theseo-llms-admin-css');
}
add_action('admin_enqueue_scripts', 'theseo_llms_admin_assets');

/**
 * Admin menu toevoegen
 */
function theseo_llms_admin_menu() {
    add_options_page(
        theseo_llms_t('llms txt generator', 'llms txt generator'),
        theseo_llms_t('llms txt generator', 'llms txt generator'),
        'manage_options',
        'theseo-llms-generator',
        'theseo_llms_settings_page'
    );
}
add_action('admin_menu', 'theseo_llms_admin_menu');

/**
 * Settings pagina renderen
 */
function theseo_llms_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['theseo_llms_save'])) {
        check_admin_referer('theseo_llms_save_settings');

$options = array();

$site_name       = isset( $_POST['site_name'] ) ? wp_unslash( $_POST['site_name'] ) : '';
$site_url        = isset( $_POST['site_url'] ) ? wp_unslash( $_POST['site_url'] ) : '';
$language        = isset( $_POST['language'] ) ? wp_unslash( $_POST['language'] ) : 'nl';
$priority_path   = isset( $_POST['priority_path'] ) ? wp_unslash( $_POST['priority_path'] ) : '';
$topics_input    = isset( $_POST['topics'] ) ? wp_unslash( $_POST['topics'] ) : '';
$clusters_input  = isset( $_POST['clusters'] ) ? wp_unslash( $_POST['clusters'] ) : '';
$context_input   = isset( $_POST['context'] ) ? wp_unslash( $_POST['context'] ) : '';
$block_paths_inp = isset( $_POST['block_paths'] ) ? wp_unslash( $_POST['block_paths'] ) : '';
$citation_input  = isset( $_POST['citation'] ) ? wp_unslash( $_POST['citation'] ) : 'full';

$options['site_name']        = sanitize_text_field( $site_name );
$options['site_url']         = esc_url_raw( trim( $site_url ) );
$options['language']         = sanitize_text_field( $language );
$options['priority_path']    = trim( sanitize_text_field( $priority_path ) );
$options['topics']           = trim( wp_kses_post( $topics_input ) );
$options['clusters']         = trim( sanitize_text_field( $clusters_input ) );
$options['context']          = trim( wp_kses_post( $context_input ) );
$options['block_paths']      = trim( wp_kses_post( $block_paths_inp ) );
$options['citation']         = sanitize_text_field( $citation_input );
$options['show_attribution'] = isset( $_POST['show_attribution'] ) ? 1 : 0;


        update_option(theseo_llms_option_key(), $options);

        echo '<div class="updated"><p>' . esc_html(theseo_llms_t('Settings saved.', 'Instellingen opgeslagen.')) . '</p></div>';
    }

    $opts     = theseo_llms_get_options();
    $llms_url = home_url('/llms.txt');
    ?>
    <div class="wrap theseo-llms-admin">
        <h1><?php echo esc_html(theseo_llms_t('llms txt generator', 'llms txt generator')); ?></h1>
        <p>
            <?php echo esc_html(theseo_llms_t(
                'This plugin generates a dynamic llms txt file that is available at',
                'Deze plugin maakt automatisch een dynamisch llms txt bestand beschikbaar op'
            )); ?>
            <code><?php echo esc_html($llms_url); ?></code>
        </p>

        <div class="theseo-llms-panel">
            <p>
                <strong><?php echo esc_html(theseo_llms_t('Developed by TheSEO', 'Ontwikkeld door TheSEO')); ?></strong><br>
                <?php echo wp_kses_post(theseo_llms_t(
                    'This plugin is developed and maintained by <a href="https://www.theseo.nl" target="_blank" rel="noopener">TheSEO.nl</a>. It helps you prepare your site for modern AI crawlers like ChatGPT, Perplexity and Gemini.',
                    'Deze plugin is ontwikkeld en wordt onderhouden door <a href="https://www.theseo.nl" target="_blank" rel="noopener">TheSEO.nl</a>. De plugin helpt je site klaar te maken voor moderne AI crawlers zoals ChatGPT Perplexity en Gemini.'
                )); ?>
            </p>
        </div>

        <form method="post" style="margin-top:20px;">
            <?php wp_nonce_field('theseo_llms_save_settings'); ?>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="site_name"><?php echo esc_html(theseo_llms_t('Website name', 'Website naam')); ?></label></th>
                    <td>
                        <input type="text" id="site_name" name="site_name" class="regular-text"
                               value="<?php echo esc_attr($opts['site_name']); ?>">
                        <p class="description"><?php echo esc_html(theseo_llms_t('For example your brand or platform name.', 'Bijvoorbeeld de naam van je merk of platform.')); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="site_url"><?php echo esc_html(theseo_llms_t('Base URL', 'Basis URL')); ?></label></th>
                    <td>
                        <input type="text" id="site_url" name="site_url" class="regular-text"
                               value="<?php echo esc_attr($opts['site_url']); ?>">
                        <p class="description">
                            <?php echo esc_html(theseo_llms_t('Without llms txt at the end.', 'Zonder llms txt erachter.')); ?>
                            <?php echo ' ' . esc_html(theseo_llms_t('Example', 'Bijvoorbeeld')) . ' ' . esc_html(home_url('/')); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="language"><?php echo esc_html(theseo_llms_t('Language', 'Taal')); ?></label></th>
                    <td>
                        <select id="language" name="language">
                            <option value="nl" <?php selected($opts['language'], 'nl'); ?>>Nederlands</option>
                            <option value="en" <?php selected($opts['language'], 'en'); ?>>English</option>
                            <option value="mixed" <?php selected($opts['language'], 'mixed'); ?>>Meertalig</option>
                        </select>
                        <p class="description"><?php echo esc_html(theseo_llms_t('Signal for language models.', 'Signaal voor taalmodellen.')); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="priority_path"><?php echo esc_html(theseo_llms_t('Primary section', 'Belangrijkste sectie')); ?></label></th>
                    <td>
                        <input type="text" id="priority_path" name="priority_path" class="regular-text"
                               value="<?php echo esc_attr($opts['priority_path']); ?>">
                        <p class="description"><?php echo esc_html(theseo_llms_t('For example /blog/ or /knowledge-base/.', 'Bijvoorbeeld /blog/ of /kennisbank/.')); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="topics"><?php echo esc_html(theseo_llms_t('Main topics', 'Hoofd onderwerpen')); ?></label></th>
                    <td>
                        <textarea id="topics" name="topics" rows="5" class="large-text code"><?php echo esc_textarea($opts['topics']); ?></textarea>
                        <p class="description"><?php echo esc_html(theseo_llms_t('One topic per line. These are your focus areas.', 'Eén onderwerp per regel. Dit zijn je focus thema’s.')); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="clusters"><?php echo esc_html(theseo_llms_t('Clusters', 'Clusters')); ?></label></th>
                    <td>
                        <input type="text" id="clusters" name="clusters" class="regular-text"
                               value="<?php echo esc_attr($opts['clusters']); ?>">
                        <p class="description"><?php echo esc_html(theseo_llms_t('Comma separated list of important themes.', 'Komma gescheiden lijst met belangrijke thema’s.')); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="context"><?php echo esc_html(theseo_llms_t('Website context', 'Website context')); ?></label></th>
                    <td>
                        <textarea id="context" name="context" rows="4" class="large-text code"><?php echo esc_textarea($opts['context']); ?></textarea>
                        <p class="description"><?php echo esc_html(theseo_llms_t('Short explanation for AI about what your site does.', 'Korte uitleg voor AI over wat je site doet.')); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="block_paths"><?php echo esc_html(theseo_llms_t('Lower priority paths', 'Minder relevante paden')); ?></label></th>
                    <td>
                        <textarea id="block_paths" name="block_paths" rows="4" class="large-text code"><?php echo esc_textarea($opts['block_paths']); ?></textarea>
                        <p class="description"><?php echo esc_html(theseo_llms_t('One path per line. These are treated as lower priority.', 'Eén pad per regel. Wordt als lagere prioriteit aangegeven.')); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="citation"><?php echo esc_html(theseo_llms_t('Citation preference', 'Citatie voorkeur')); ?></label></th>
                    <td>
                        <select id="citation" name="citation">
                            <option value="full" <?php selected($opts['citation'], 'full'); ?>>
                                <?php echo esc_html(theseo_llms_t(
                                    'AI may quote definitions checklists and step by step instructions verbatim',
                                    'AI mag definities checklists en stappenplannen letterlijk citeren'
                                )); ?>
                            </option>
                            <option value="partial" <?php selected($opts['citation'], 'partial'); ?>>
                                <?php echo esc_html(theseo_llms_t(
                                    'AI may quote short fragments but should prefer summaries',
                                    'AI mag korte fragmenten citeren maar liever samenvattingen'
                                )); ?>
                            </option>
                            <option value="summary" <?php selected($opts['citation'], 'summary'); ?>>
                                <?php echo esc_html(theseo_llms_t(
                                    'AI should not quote verbatim and only provide summaries',
                                    'AI mag niet letterlijk citeren en alleen samenvattingen geven'
                                )); ?>
                            </option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><?php echo esc_html(theseo_llms_t('Attribution link', 'Attributie link')); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="show_attribution" value="1" <?php checked($opts['show_attribution'], 1); ?>>
                            <?php echo esc_html(theseo_llms_t(
                                'Show a small “Developed by TheSEO” link in the footer',
                                'Toon een kleine “Ontwikkeld door TheSEO” link in de footer'
                            )); ?>
                        </label>
                        <p class="description">
                            <?php echo esc_html(theseo_llms_t(
                                'Optional but helps users discover TheSEO.',
                                'Optioneel maar helpt gebruikers om TheSEO te ontdekken.'
                            )); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="submit" name="theseo_llms_save" class="button button-primary">
                    <?php echo esc_html(theseo_llms_t('Save settings', 'Instellingen opslaan')); ?>
                </button>
            </p>
        </form>

        <h2><?php echo esc_html(theseo_llms_t('Preview of your current llms txt', 'Voorbeeld van het huidige llms txt')); ?></h2>
        <pre class="theseo-llms-preview"><?php
            echo esc_html(theseo_llms_build_txt($opts));
        ?></pre>
    </div>
    <?php
}

/**
 * Query var registreren
 */
function theseo_llms_query_vars($vars) {
    $vars[] = 'theseo_llms_txt';
    return $vars;
}
add_filter('query_vars', 'theseo_llms_query_vars');

/**
 * Rewrite regel voor llms txt
 */
function theseo_llms_add_rewrite_rule() {
    add_rewrite_rule('^llms\.txt$', 'index.php?theseo_llms_txt=1', 'top');
}
add_action('init', 'theseo_llms_add_rewrite_rule');

/**
 * Flush rewrites bij activatie en deactivatie
 */
function theseo_llms_activate() {
    theseo_llms_add_rewrite_rule();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'theseo_llms_activate');

function theseo_llms_deactivate() {
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'theseo_llms_deactivate');

/**
 * llms txt output
 */
function theseo_llms_template_redirect() {
    $flag = get_query_var('theseo_llms_txt');
    if ($flag) {
        $opts = theseo_llms_get_options();
        $txt  = theseo_llms_build_txt($opts);

        nocache_headers();
header( 'Content-Type: text/plain; charset=utf-8' );
// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plain text response for llms.txt
echo $txt;
exit;

    }
}
add_action('template_redirect', 'theseo_llms_template_redirect');

/**
 * Optionele footer link
 */
function theseo_llms_footer_attribution() {
    $opts = theseo_llms_get_options();
    if (empty($opts['show_attribution'])) {
        return;
    }
    echo '<p style="text-align:center;font-size:11px;opacity:.65;margin:10px 0;">' .
         wp_kses_post(theseo_llms_t(
             'llms txt managed by <a href="https://www.theseo.nl" target="_blank" rel="noopener">TheSEO.nl</a>',
             'llms txt beheerd door <a href="https://www.theseo.nl" target="_blank" rel="noopener">TheSEO.nl</a>'
         )) .
         '</p>';
}
add_action('wp_footer', 'theseo_llms_footer_attribution');

