=== TheSEO llms txt Generator ===
Contributors: theseo
Tags: ai optimalisation, seo, llms, chatgpt, gemini
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

TheSEO llms txt Generator creates a dynamic llms txt file at /llms.txt based on your WordPress settings.  
llms txt is a helper file for modern language models such as ChatGPT, Perplexity and Google Gemini.  
It defines your main topics, clusters, content context and citation preferences so AI crawlers understand your site better.

Features:

* Dynamic llms txt output at /llms.txt
* Multilingual admin (Dutch + English)
* Customisable topics, clusters and context
* Adjustable citation preferences
* Optional attribution link in the footer
* Non-intrusive implementation

Developed by https://www.theseo.nl

== Installation ==

1. Upload the `theseo-llms-txt-generator` folder to the `/wp-content/plugins/` directory, or upload the zip via the WordPress plugin installer.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. Go to "Settings → llms txt generator".
4. Fill in your site information and save.
5. Visit `https://yourdomain.com/llms.txt` to confirm the output.

== Frequently Asked Questions ==

= Where is my llms txt file located? =
After activation and saving your settings, it is automatically available at /llms.txt.

= Does this plugin work with every WordPress theme? =
Yes. It works independently of your theme.

= Does this plugin modify my database? =
It only stores settings in one WordPress option.

= Does it add hidden backlinks? =
Only optional attribution, visible to users, which can be disabled at any time.

== Changelog ==

= 1.1.2 =
* Moved admin inline styles into a separate CSS file loaded via wp_enqueue_style.
* Improved compatibility with WordPress.org plugin guidelines.

= 1.1.1 =
* Improved stability
* Better multilingual labels
* Added WordPress.org-ready readme

= 1.1.0 =
* Added bilingual admin labels (Dutch + English)
* Added optional footer attribution
* Added branding comments in llms txt output

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.1.2 =
Recommended update. Moves inline admin styles into proper enqueued CSS to comply with WordPress.org guidelines.

= 1.1.1 =
Important for WordPress.org submission. Adds full readme compliance.

